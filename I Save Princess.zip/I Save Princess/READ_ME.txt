Note: to play game, open I Save Princess Game.exe

I Save Princess Intructions:

-Help the Hero save the princess.
-Avoid the evil crabs or the Hero will perish.
-Swipe the tiles up, down, left, or right to shift the layout of the maze to avoid the crabs,
in order to reach and save the princess. 


Credits:

Christopher Alfonso			
Taylor Bai-Woo			
Colin Janowicz			
Kristopher Maddeaux